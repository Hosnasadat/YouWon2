import java.util.Arrays;
import java.util.Scanner;
import java.util.Random;

public class HHosna {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Random random = new Random();

        int[] numbers = new int[4];
        int attempts = 0;

        for (int i = 0; i < numbers.length; i++) {
            numbers[i] = random.nextInt(10);
        }

        while (true) {
            attempts += 1;

            System.out.printf("User – attempt %d: ", attempts);
            String[] guess = input.nextLine().split(",");

            int[] result = new int[4];
            int[] temp = Arrays.copyOf(numbers, 4);
            int counter = 0;

            for (int i = 0; i < 4; i++) {
                result[i] = -1;
                if (Integer.parseInt(guess[i]) == temp[i]) {
                    result[i] = 1;
                    temp[i] = -1;
                    counter++;
                } else {
                    for (int j = 0; j < 4; j++) {
                        if (temp[j] != -1 && temp[j] != Integer.parseInt(guess[j]) && temp[j] == Integer.parseInt(guess[i])) {
                            result[i] = 0;
                            temp[j] = -1;
                            break;
                        }
                    }
                }
            }

            System.out.print("result: ");
            for (int i = 0; i < 4; i++) {
                if (result[i] != -1) {
                    System.out.print(result[i]);
                }
            }

            System.out.println();

            if (counter == 4) {
                System.out.printf("You Won in %d Steps", attempts);
                break;
            }
        }
    }
}